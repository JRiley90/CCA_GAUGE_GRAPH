import mpmath as mp, json, time
from ladder import B,mult
def run(dps,tol):
    mp.mp.dps=dps
    K=mp.mpf(1)/2
    def Hm(k,tau,g):
        M=mp.zeros(64,64)
        for x in range(64): M[x,x]=-K*sum(1-2*((x>>i)&1) for i in range(6))
        for v,m in mult(k).items():
            a=m*mp.e**(-tau*(m-1))
            for x in range(64): M[x,x^v]-=g*a
        return M
    e0=lambda k,t,g:min(mp.eigsy(Hm(k,t,g),eigvals_only=True))
    tc2=-mp.log((mp.sqrt(226)-8)/18)/2
    a1=-mp.mpf('3.636611744391253')/mp.mpf('-11.74818099700186')*-1
    out={}
    for gs in ['0.002','0.001','0.0005','0.0002','0.0001']:
        g=mp.mpf(gs);guess=tc2-mp.mpf('0.30954679241997696')*g
        out[gs]=mp.findroot(lambda t:e0('T10',t,g)-e0('P5',t,g),(guess-mp.mpf('1e-4'),guess+mp.mpf('1e-4')),solver='anderson',tol=tol,maxsteps=60)
    return out,tc2
r40,tc2=run(40,1e-30)
r60,_=run(60,1e-45)
mp.mp.dps=60
canon={'0.002':'0.4692051514033929','0.001':'0.4695401454094673','0.0005':'0.4697012515365259','0.0002':'0.4697958818370814','0.0001':'0.4698270588560223'}
d={'mpmath_version':mp.__version__,'working_precision_digits':40,'confirmation_precision_digits':60,
 'solver':'mpmath.findroot(anderson), tol 1e-30 (40 dps) / 1e-45 (60 dps); eigenvalues via mpmath.eigsy',
 'binary64_solver':'scipy brentq xtol=1e-14 rtol=4*eps',
 'note':'arbitrary-precision floating point, not interval enclosures; independent reconstruction of H_A, not yet produced by the frozen pipeline','rows':[]}
for g in canon:
    a=r40[g];b=r60[g]
    print(g,mp.nstr(a,20),'agree40v60 %.1e'%float(abs(a-b)),'canon-HP %.2e'%float(mp.mpf(canon[g])-a))
    d['rows'].append({'g':g,'tau_c_hp40':mp.nstr(a,25),'tau_c_hp60':mp.nstr(b,25),'tau_c_binary64_canonical':canon[g]})
json.dump(d,open('ladder_highprecision.json','w'),indent=1)
print(mp.__version__)
