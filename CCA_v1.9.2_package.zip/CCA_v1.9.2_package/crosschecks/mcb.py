import itertools
from ladder import B
Bx={'T8':[[0,1,8],[2,3,9],[4,5,10],[6,7,11],[8,9,10,11]],'Q3':[[0,1,2,3],[0,9,4,8],[3,10,7,8],[1,11,5,9],[2,11,6,10]],
'W8':[[0,1,2,3,8],[1,2,3,4,9],[2,3,4,5,10],[3,4,5,6,11],[0,1,2,3,4,5,6,7]],'T10':B['T10'],'P5':B['P5']}
for k,b in Bx.items():
    ev=[sum(1<<e for e in C) for C in b];n=len(b)
    span=set()
    for m in range(1,1<<n):
        x=0
        for i in range(n):
            if (m>>i)&1:x^=ev[i]
        span.add(x)
    els=sorted(span,key=lambda x:bin(x).count('1'))
    basis=[];red=[]
    def reduce(x,red):
        for r in red: x=min(x,x^r)
        return x
    tot=0
    for x in els:
        y=reduce(x,red)
        if y: red.append(y);red.sort(reverse=True);tot+=bin(x).count('1')
        if len(red)==n:break
    print(k,'canonical length',sum(len(C) for C in b),'min possible',tot)
