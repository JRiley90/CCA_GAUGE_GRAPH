import numpy as np, scipy.sparse as sp
from scipy.sparse.linalg import eigsh
from mcb import Bx
ev=[sum(1<<e for e in C) for C in Bx['W8']];n=5
span=set()
for m in range(1,1<<n):
    x=0
    for i in range(n):
        if (m>>i)&1:x^=ev[i]
    span.add(x)
els=sorted(span,key=lambda x:(bin(x).count('1'),x))
red=[];basis=[]
for x in els:
    y=x
    for r in red:y=min(y,y^r)
    if y:red.append(y);red.sort(reverse=True);basis.append(x)
    if len(basis)==5:break
print([[e for e in range(12) if (x>>e)&1] for x in basis])
J,K,g=1.0,0.5,0.15
def E0(cyc,N=12):
    D=1<<N;s=np.arange(D)
    pc=lambda x:np.array([bin(i).count('1')&1 for i in x])
    d=-J*sum(1-2*((s>>e)&1) for e in range(N)).astype(float)
    for m in cyc: d-=K*(1-2*pc(s&m))
    H=sp.diags(d)
    for e in range(N): H=H+sp.csr_matrix((np.full(D,-g),(s,s^(1<<e))),shape=(D,D))
    return eigsh(H.tocsr(),k=1,which='SA')[0][0]
print('W8 min-length basis E0',E0(basis),'canonical',E0(ev))
