import random, numpy as np
from scipy.optimize import brentq
from mcb import Bx
random.seed(3)
pc=lambda x:bin(x).count('1')
def space(b):
    ev=[sum(1<<e for e in C) for C in b];n=len(b);S=set()
    for m in range(1,1<<n):
        x=0
        for i in range(n):
            if (m>>i)&1:x^=ev[i]
        S.add(x)
    return sorted(S)
def randmin(S,n):
    els=S[:];random.shuffle(els);els.sort(key=pc)
    red=[];basis=[]
    for x in els:
        y=x
        for r in red:y=min(y,y^r)
        if y:red.append(y);red.sort(reverse=True);basis.append(x)
        if len(basis)==n:break
    return basis
def masks(basis):
    import collections
    return collections.Counter(sum(1<<i for i,x in enumerate(basis) if (x>>e)&1) for e in range(15))
def C2(m,tau):
    return sum((mm*np.exp(-tau*(mm-1)))**2/pc(v) for v,mm in m.items() if v)
ST,SP=space(Bx['T10']),space(Bx['P5'])
vals=set();taus=[]
for _ in range(3000):
    mT=masks(randmin(ST,6));mP=masks(randmin(SP,6))
    t0=C2(mT,0);p=C2(mP,0);vals.add((round(t0,6),round(p,6)))
    if C2(mT,60)<p<t0: taus.append(brentq(lambda t:C2(mT,t)-p,0,60))
print(sorted(vals)[:6],len(vals))
print('tau_c across random min-length bases: min %.4f max %.4f n=%d'%(min(taus),max(taus),len(taus)))
