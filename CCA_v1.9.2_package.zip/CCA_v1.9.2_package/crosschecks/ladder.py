import numpy as np, collections
from scipy.optimize import brentq
B={'T10':[[0,1,2],[2,3,4],[4,5,6],[6,7,8],[8,9,10,11],[11,12,13,14]],
'P5':[[0,10,5,14],[1,11,6,10],[2,12,7,11],[3,13,8,12],[4,14,9,13],[0,1,2,3,4]]}
def mult(k):
    c=collections.Counter(sum(1<<i for i,C in enumerate(B[k]) if e in C) for e in range(15)); c.pop(0,None); return c
K=0.5
def H(k,tau,g):
    D=64;M=np.zeros((D,D));s=np.arange(D)
    for x in s: M[x,x]=-K*sum(1-2*((x>>i)&1) for i in range(6))
    for v,m in mult(k).items():
        a=m*np.exp(-tau*(m-1))
        for x in s: M[x,x^v]-=g*a
    return M
def dE(tau,g): return np.linalg.eigvalsh(H('T10',tau,g))[0]-np.linalg.eigvalsh(H('P5',tau,g))[0]
if __name__=="__main__":
  for g in [0.002,0.001,0.0005,0.0002,0.0001]:
    r=brentq(lambda t:dE(t,g),0.4,0.5,xtol=1e-14,rtol=4*2.220446049250313e-16)
    print(g,repr(r))
