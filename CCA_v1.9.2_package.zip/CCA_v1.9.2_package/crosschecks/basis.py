import numpy as np, random, collections
from scipy.optimize import brentq
from ladder import mult
random.seed(1)
pc=lambda x:bin(x).count('1')
def rand_gl():
    while True:
        cols=[random.randrange(1,64) for _ in range(6)]
        # rank over F2
        rows=cols[:];r=0
        for b in range(6):
            piv=next((x for x in rows if (x>>b)&1),None)
            if piv is None: continue
            rows.remove(piv);rows=[x^piv if (x>>b)&1 else x for x in rows];r+=1
        if r==6: return cols
def app(cols,v):
    o=0
    for i in range(6):
        if (v>>i)&1:o^=cols[i]
    return o
def C2(m,cols,tau):
    return sum((mm*np.exp(-tau*(mm-1)))**2/pc(app(cols,v)) for v,mm in m.items())
mT,mP=mult('T10'),mult('P5')
I=[1<<i for i in range(6)]
print('canonical',C2(mT,I,0),C2(mP,I,0))
res=[];N=20000;ex=0;c2t=[];c2p=[]
for _ in range(N):
    A,Bm=rand_gl(),rand_gl()
    p=C2(mP,Bm,0);t0=C2(mT,A,0);tinf=C2(mT,A,60)
    c2t.append(t0);c2p.append(p)
    if tinf<p<t0:
        ex+=1;res.append(brentq(lambda t:C2(mT,A,t)-p,0,60))
res=np.array(res)
print('C2(T10,0) range %.2f-%.2f median %.2f'%(min(c2t),max(c2t),np.median(c2t)))
print('C2(P5) range %.2f-%.2f median %.2f'%(min(c2p),max(c2p),np.median(c2p)))
print('crossing exists %.1f%%; tau_c pct 5/50/95: %s'%(100*ex/N,np.percentile(res,[5,50,95]).round(3)))
# same random basis on both? permutation-only invariance check
import itertools
perm=[]
for _ in range(2000):
    pm=random.sample(range(6),6);cols=[1<<pm[i] for i in range(6)]
    perm.append(C2(mT,cols,0))
print('coordinate permutations: C2 values',set(round(x,6) for x in perm))
